#include "print.h"
#include "osinfo.h"

void kernel_main() {
    print_clear();
    print_set_color(PRINT_COLOR_YELLOW, PRINT_COLOR_BLACK);
    print_str(os_version);
    print_str("\n");
    print_str("\n");
    print_str("\n");
    print_str("Welcome to Skl-os Kernel!");
}