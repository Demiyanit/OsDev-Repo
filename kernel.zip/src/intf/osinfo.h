#pragma once

extern char os_version[] = "Skl-os Kernel module V0.0.1-inDev";
